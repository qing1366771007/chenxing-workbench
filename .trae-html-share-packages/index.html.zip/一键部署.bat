@echo off
chcp 65001 >nul
cd /d "E:\青的obsidian\辰星工作台"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "E:\青的obsidian\辰星工作台\deploy-github.ps1" -Token "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"
pause
